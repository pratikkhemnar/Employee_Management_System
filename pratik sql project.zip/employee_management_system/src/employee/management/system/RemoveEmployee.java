package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;

public class RemoveEmployee extends JFrame implements ActionListener {
    Choice choiceempid;
    JButton delete, back;

    RemoveEmployee() {
        // Employee ID label and dropdown
        JLabel label = new JLabel("Employee Id");
        label.setBounds(50, 50, 100, 30);
        label.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(label);

        choiceempid = new Choice();
        choiceempid.setBounds(200, 50, 150, 30);
        add(choiceempid);

        // Populate employee dropdown with employee IDs
        try {
            Conn c = new Conn();
            ResultSet resultSet = c.statement.executeQuery("select * from employee");
            while (resultSet.next()) {
                choiceempid.add(resultSet.getString("empid"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Name label and value
        JLabel labelName = new JLabel("Name");
        labelName.setBounds(50, 100, 100, 30);
        labelName.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(labelName);

        JLabel textName = new JLabel();
        textName.setBounds(200, 100, 100, 30);
        add(textName);

        // Phone label and value
        JLabel labelPhone = new JLabel("Phone");
        labelPhone.setBounds(50, 150, 100, 30);
        labelPhone.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(labelPhone);

        JLabel textPhone = new JLabel();
        textPhone.setBounds(200, 150, 100, 30);
        add(textPhone);

        // Email label and value
        JLabel labelEmail = new JLabel("Email");
        labelEmail.setBounds(50, 200, 100, 30);
        labelEmail.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(labelEmail);

        JLabel textEmail = new JLabel();
        textEmail.setBounds(200, 200, 100, 30);
        add(textEmail);

        // Set initial values for Name, Phone, and Email
        updateEmployeeDetails(choiceempid.getSelectedItem(), textName, textPhone, textEmail);

        // Add an ItemListener to update the fields when a new employee ID is selected
        choiceempid.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                updateEmployeeDetails(choiceempid.getSelectedItem(), textName, textPhone, textEmail);
            }
        });

        // Delete button
        delete = new JButton("Delete");
        delete.setBounds(80, 300, 100, 30);
        delete.setBackground(Color.BLACK);
        delete.setForeground(Color.WHITE);
        delete.addActionListener(this);
        add(delete);

        // Back button
        back = new JButton("Back");
        back.setBounds(220, 300, 100, 30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);

        // Image icons
        ImageIcon deleteIcon = new ImageIcon(ClassLoader.getSystemResource("icons/delete.png"));
        Image deleteImg = deleteIcon.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
        JLabel img = new JLabel(new ImageIcon(deleteImg));
        img.setBounds(700, 80, 200, 200);
        add(img);

        // Background image
        ImageIcon bgIcon = new ImageIcon(ClassLoader.getSystemResource("icons/rback.png"));
        Image bgImg = bgIcon.getImage().getScaledInstance(1120, 630, Image.SCALE_DEFAULT);
        JLabel background = new JLabel(new ImageIcon(bgImg));
        background.setBounds(0, 0, 1120, 630);
        add(background);

        // JFrame properties
        setSize(1000, 400);
        setLocation(300, 150);
        setLayout(null);
        setVisible(true);
    }

    // Method to update employee details based on selected empid
    private void updateEmployeeDetails(String empid, JLabel textName, JLabel textPhone, JLabel textEmail) {
        try {
            Conn c = new Conn();
            ResultSet resultSet = c.statement.executeQuery("select * from employee where empid='" + empid + "'");
            if (resultSet.next()) {
                textName.setText(resultSet.getString("name"));
                textPhone.setText(resultSet.getString("phone"));
                textEmail.setText(resultSet.getString("email"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == delete) {
            try {
                Conn c = new Conn();
                String query = "delete from employee where empid='" + choiceempid.getSelectedItem() + "'";
                c.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Employee Deleted Successfully");
                setVisible(false);
                new Main_class();  // Assuming Main_class exists
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == back) {
            setVisible(false);
            new Main_class();  // Assuming Main_class exists
        }
    }

    public static void main(String[] args) {
        new RemoveEmployee();
    }
}
