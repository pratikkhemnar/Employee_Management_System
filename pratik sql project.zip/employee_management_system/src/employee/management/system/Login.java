package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener {
    private JTextField tusername;
    private JPasswordField tpass;
    private final JButton login;
    private final JButton back;

    Login(){
        JLabel username=new JLabel("UserName");
        username.setBounds(40,20,100,30);
        add(username);

        tusername = new JTextField();
        tusername.setBounds(150,20,150,30);
        add(tusername);

        JLabel password=new JLabel("Password");
        password.setBounds(40,70,100,30);
        add(password);

        tpass = new JPasswordField();
        tpass.setBounds(150,70,150,30);
        add(tpass);

        login = new JButton("LOGIN");
        login.setBounds(150,140,150,30);
        login.setBackground(Color.BLACK);
        login.setForeground(Color.white);
        login.addActionListener(this);
        add(login);

        back = new JButton("BACK");
        back.setBounds(150,180,150,30);
        back.setBackground(Color.black);
        back.setForeground(Color.white);
        back.addActionListener(this);
        add(back);

        ImageIcon i11 = new ImageIcon(ClassLoader.getSystemResource("Icons/Lg2.png"));
        Image i22 = i11.getImage().getScaledInstance(600,400, Image.SCALE_DEFAULT);
        ImageIcon i33 = new ImageIcon(i22);
        JLabel img = new JLabel(i33);
        img.setBounds(350,10,600,400);
        add(img);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/img_2.png"));
        Image i2 = i1.getImage().getScaledInstance(600,300, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel img2 = new JLabel(i3);
        img2.setBounds(0,0,600,300);
        add(img2);

        setSize(600,300);
        setLocation(500,250);
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == login){
            try {
                String username = tusername.getText();
                String password = new String(tpass.getPassword());

                Conn conn=new Conn();

                String query = "select * from login where username='" + username +"' and password = '" + password +"'";
                ResultSet resultSet =conn.statement.executeQuery(query);

                if (resultSet.next()){
                    setVisible(false);
                    new Main_class();
                }else {
                    JOptionPane.showMessageDialog(null,"Invalid UserName or Password");
                }

            }catch (Exception E){
                E.printStackTrace();
            }
        }
        else if (e.getSource() == back) {
            System.exit(0); // Exit the system when the "BACK" button is clicked
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}